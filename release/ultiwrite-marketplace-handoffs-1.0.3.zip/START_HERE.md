# Ultiwrite marketplace handoffs

Open [the channel guide](distribution/MARKETPLACES.md). The Microsoft source and Cursor archives are in `release/`.
